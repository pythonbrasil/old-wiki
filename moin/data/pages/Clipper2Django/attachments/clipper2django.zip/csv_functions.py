#!/usr/bin/python

d={'C':'models.CharField(maxlength=%d)','D':'models.DateField()','N':'models.FloatField(max_digits=%d, decimal_places=%d)'}

def getFieldList(row):
    field_list = []
    for field_def in row:
        def_list = field_def.split('|')
        field_name = def_list[0].lower()
        field_type = def_list[1]
        field_precision = int(def_list[2])
        field_decimal = int(def_list[3])
        field_list.append({'field_name':field_name,
                           'field_type':field_type,
                           'field_precision':field_precision,
                           'field_decimal':field_decimal})
    return field_list

