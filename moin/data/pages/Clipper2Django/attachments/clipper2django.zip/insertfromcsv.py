#!/usr/bin/python

import csv
import glob
from csv_functions import d, getFieldList
from getopt import getopt
import sys

def InsertFromCSV(filename=''):
    insert_template = 'INSERT INTO %s (%s) VALUES (%s);\n'
    result_list = []
    f=open(filename)
    f.seek(0)
    table_name = filename.split('/')[-1].split('.')[0].lower()
    csv_reader = csv.reader(f)
    row = csv_reader.next()
    field_list = getFieldList(row)
    result_list = []
    for row in csv_reader:
        value_list = []
        field_name_list = []
        for idx, field_def in enumerate(field_list):
            field_value = insert_field_format(field_def['field_type'],row[idx])
            value_list.append(field_value)
            field_name_list.append(field_def['field_name'])
        result_list.append(insert_template % (table_name,','.join(field_name_list),','.join(value_list)))
    return ''.join(result_list)

def insert_field_format(field_type,field_value):
    if field_type == 'N':
        return field_value
    else:
        return '"%s"' % field_value

def SQLInsertFromFiles(globstring):
    file_list = glob.glob(globstring)
    result_list = []
    for file_name in file_list:
        result_list.append(InsertFromCSV(file_name))

    return '\n'.join(result_list)

def main(args=sys.argv):
	optlist, list = getopt(args[1:], ':f:')
    for opt in optlist:
        if opt[0] == '-f':
            globExpr = opt[1]
    print '-- SQL - Insert\n'
    print SQLInsertFromFiles(globExpr)

if __name__ == '__main__':
    main()
