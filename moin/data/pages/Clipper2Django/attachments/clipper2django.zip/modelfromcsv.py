#!/usr/bin/python

import csv
import glob
from csv_functions import d, getFieldList
from getopt import getopt
import sys

def model(type, digits=0, decimal_places=0, maxlength=0):
    if type == 'N':
        return d[type] % (digits,decimal_places)
    elif type == 'C':
        return d[type] % maxlength
    else:
        return d[type]

def ModelFromCSV(filename):
    ''' Usage : ModelFromcsv('<LOCATION>/<CSVFILE>')
    '''
    class_template = 'class %s(models.Model):\n'
    field_template = '    %s = %s\n'
    result_list = []
    f=open(filename)
    f.seek(0)
    class_name = filename.split('/')[-1].split('.')[0].capitalize()
    csv_reader = csv.reader(f)
    row = csv_reader.next()
    field_list = getFieldList(row)

    class_def = class_template % class_name
    field_list = [field_template % (x['field_name'],model(x['field_type'],x['field_precision'],x['field_decimal'],x['field_precision'])) for x in field_list]
    result_list.append([class_def]+field_list)

    return ''.join([''.join(x) for x in result_list])

def ModelFromFiles(globstring):
    file_list = glob.glob(globstring)
    result_list = []
    for file_name in file_list:
        result_list.append(ModelFromCSV(file_name))

    return '\n'.join(result_list)

def main(args=sys.argv):
    optlist, list = getopt(args[1:], ':f:')
    for opt in optlist:
        if opt[0] == '-f':
            globExpr = opt[1]
    print '# Model genereted by modelfromcsv\n'
    print ModelFromFiles(globExpr)

if __name__ == '__main__':
    main()
