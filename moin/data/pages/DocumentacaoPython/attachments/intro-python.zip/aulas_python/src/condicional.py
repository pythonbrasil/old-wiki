#!/usr/bin/env python
# -*- encoding: iso-8859-1 -*-

variavel1 = 1
variavel2 = 2

if variavel1 == 1:
    print "variavel1 igual a 1"
elif variavel1 !=1 or not variavel2 == 2:
    print "variavel1 diferente de 1 ou variavel2 diferente de 2"
elif variavel1 >= 1000 or variavel2 <= -1000:
    print "variavel1 maior que 1000 ou vari�vel2 menor que -1000"
else:
    print "nenhuma das alternativas anteriores"
