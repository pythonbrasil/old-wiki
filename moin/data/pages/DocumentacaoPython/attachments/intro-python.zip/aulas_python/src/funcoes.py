#!/usr/bin/env python
# -*- encoding: iso-8859-1 -*-

def fatorial( numero ):
	"""
	Fun��o recursiva que retorna o valor do fatorial do n�mero dado.
	"""
	
	if numero <= 1:
		return 1
	else:
		return ( numero * fatorial( numero - 1 ) )
# end fatorial

for n in range( 1, 11 ):
	print "Fatorial de %d � %d" % ( n, fatorial( n ) )
# end for n

print "\nDocumenta��o da fun��o fatorial:\n" + fatorial.__doc__