#!/usr/bin/env python
# -*- encoding: iso-8859-1 -*-

print "hello world!"
