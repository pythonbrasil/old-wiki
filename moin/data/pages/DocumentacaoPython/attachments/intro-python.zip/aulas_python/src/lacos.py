#!/usr/bin/env python
# -*- encoding: iso-8859-1 -*-

for fruta in [ "banana", "ma��", "uva" ]:
    print "Fruta: " + fruta
# end for fruta

for i in range( 0, 10 ):
    print "i = " + str( i )
# end for i

i = 0
while i < 10:
    print "i = %d" % i
    i += 1
# end while i