#Boa:Frame:wxFrame1

from wxPython.wx import *
from sys import exit

def create(parent):
    return wxFrame1(parent)

[wxID_WXFRAME1, wxID_WXFRAME1BUTTON1, wxID_WXFRAME1IMAGEM, 
] = map(lambda _init_ctrls: wxNewId(), range(3))

[wxID_WXFRAME1TIMER1] = map(lambda _init_utils: wxNewId(), range(1))

class wxFrame1(wxFrame):
    def _init_utils(self):
        # generated method, don't edit
        self.Timer1 = wxTimer(evtHandler=self, id=wxID_WXFRAME1TIMER1)
        EVT_TIMER(self, wxID_WXFRAME1TIMER1, self.OnTimer1Timer)

    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wxFrame.__init__(self, id=wxID_WXFRAME1, name='', parent=prnt,
              pos=wxPoint(322, 171), size=wxSize(147, 140),
              style=wxDEFAULT_FRAME_STYLE, title='Anima\xe7\xe3o')
        self._init_utils()
        self.SetClientSize(wxSize(139, 113))

        self.imagem = wxStaticBitmap(bitmap=wxBitmap('C:/windows/desktop/progama\xe7\xe3o\\teste para anima\xe7\xe3o/Imagens/guitarra0.jpg',
              wxBITMAP_TYPE_JPEG), id=wxID_WXFRAME1IMAGEM, name='imagem',
              parent=self, pos=wxPoint(24, 8), size=wxSize(89, 70), style=0)

        self.button1 = wxButton(id=wxID_WXFRAME1BUTTON1, label='Sair',
              name='button1', parent=self, pos=wxPoint(40, 88), size=wxSize(59,
              24), style=0)
        EVT_BUTTON(self.button1, wxID_WXFRAME1BUTTON1, self.OnButton1Button)

    def __init__(self, parent):
        self._init_ctrls(parent)
        self.indice=0
        self.Timer1.Start(150)
        self.bm1=wxBitmap('./Imagens/guitarra1.jpg',wxBITMAP_TYPE_JPEG)
        self.bm2=wxBitmap('./Imagens/guitarra2.jpg',wxBITMAP_TYPE_JPEG)
        self.bm3=wxBitmap('./Imagens/guitarra3.jpg',wxBITMAP_TYPE_JPEG)
        self.bm4=wxBitmap('./Imagens/guitarra4.jpg',wxBITMAP_TYPE_JPEG)
        self.bm5=wxBitmap('./Imagens/guitarra5.jpg',wxBITMAP_TYPE_JPEG)
        self.bm6=wxBitmap('./Imagens/guitarra6.jpg',wxBITMAP_TYPE_JPEG)
        self.bm7=wxBitmap('./Imagens/guitarra7.jpg',wxBITMAP_TYPE_JPEG)
        self.bm8=wxBitmap('./Imagens/guitarra8.jpg',wxBITMAP_TYPE_JPEG)
        self.bm9=wxBitmap('./Imagens/guitarra9.jpg',wxBITMAP_TYPE_JPEG)
        self.bm10=wxBitmap('./Imagens/guitarra10.jpg',wxBITMAP_TYPE_JPEG)
        self.bm11=wxBitmap('./Imagens/guitarra11.jpg',wxBITMAP_TYPE_JPEG)
        self.bm12=wxBitmap('./Imagens/guitarra12.jpg',wxBITMAP_TYPE_JPEG)
        self.bm13=wxBitmap('./Imagens/guitarra13.jpg',wxBITMAP_TYPE_JPEG)
        self.bm14=wxBitmap('./Imagens/guitarra14.jpg',wxBITMAP_TYPE_JPEG)
        self.bm15=wxBitmap('./Imagens/guitarra15.jpg',wxBITMAP_TYPE_JPEG)
        self.bm16=wxBitmap('./Imagens/guitarra16.jpg',wxBITMAP_TYPE_JPEG)
        self.bm17=wxBitmap('./Imagens/guitarra17.jpg',wxBITMAP_TYPE_JPEG)
             
    def OnTimer1Timer(self, event):
        if self.indice==0:
            self.imagem.SetBitmap(self.bm1)
            self.indice=1
            exit
        if self.indice==1:
            self.imagem.SetBitmap(self.bm2)
            self.indice=2
            return
        if self.indice==2:
            self.imagem.SetBitmap(self.bm3)
            self.indice=3
            return
        if self.indice==3:
            self.imagem.SetBitmap(self.bm4)
            self.indice=4
            return
        if self.indice==4:
            self.imagem.SetBitmap(self.bm5)
            self.indice=5
            return
        if self.indice==5:
            self.imagem.SetBitmap(self.bm6)
            self.indice=6
            return
        if self.indice==6:
            self.imagem.SetBitmap(self.bm7)
            self.indice=7
            return
        if self.indice==7:
            self.imagem.SetBitmap(self.bm8)
            self.indice=8
            return
        if self.indice==8:
            self.imagem.SetBitmap(self.bm9)
            self.indice=9
            return
        if self.indice==9:
            self.imagem.SetBitmap(self.bm10)
            self.indice=10
            return
        if self.indice==10:
            self.imagem.SetBitmap(self.bm11)
            self.indice=11
            return
        if self.indice==11:
            self.imagem.SetBitmap(self.bm12)
            self.indice=12
            return
        if self.indice==12:
            self.imagem.SetBitmap(self.bm13)
            self.indice=13
            return
        if self.indice==13:
            self.imagem.SetBitmap(self.bm14)
            self.indice=14
            return
        if self.indice==14:
            self.imagem.SetBitmap(self.bm15)
            self.indice=15
            return
        if self.indice==15:
            self.imagem.SetBitmap(self.bm16)
            self.indice=16
            return
        if self.indice==16:
            self.imagem.SetBitmap(self.bm17)
            self.indice=17
            return
        if self.indice==17:
            self.imagem.SetBitmap(self.bm1)
            self.indice=0        
            
      
    def OnButton1Button(self, event):
        message=wxMessageDialog(self,"Encerrar a Anima��o?","Anima��o",wxYES_NO|wxICON_INFORMATION)
        resp=message.ShowModal()
        if resp==5103:
            self.Close()
            exit(0)
