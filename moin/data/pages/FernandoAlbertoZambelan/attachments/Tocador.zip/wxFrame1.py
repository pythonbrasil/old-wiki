#Boa:Frame:wxFrame1

from wxPython.wx import *
from sys import exit
from pygame import mixer

def create(parent):
    return wxFrame1(parent)

[wxID_WXFRAME1, wxID_WXFRAME1BUTTON1, wxID_WXFRAME1BUTTON2, 
] = map(lambda _init_ctrls: wxNewId(), range(3))

class wxFrame1(wxFrame):
    def _init_utils(self):
        # generated method, don't edit
        pass

    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wxFrame.__init__(self, id=wxID_WXFRAME1, name='', parent=prnt,
              pos=wxPoint(354, 205), size=wxSize(127, 73),
              style=wxDEFAULT_FRAME_STYLE, title='Musica')
        self._init_utils()
        self.SetClientSize(wxSize(119, 46))

        self.button1 = wxButton(id=wxID_WXFRAME1BUTTON1, label='Tocar',
              name='button1', parent=self, pos=wxPoint(24, 0), size=wxSize(75,
              23), style=0)
        EVT_BUTTON(self.button1, wxID_WXFRAME1BUTTON1, self.OnButton1Button)

        self.button2 = wxButton(id=wxID_WXFRAME1BUTTON2, label='Sair',
              name='button2', parent=self, pos=wxPoint(24, 24), size=wxSize(75,
              23), style=0)
        EVT_BUTTON(self.button2, wxID_WXFRAME1BUTTON2, self.OnButton2Button)

    def __init__(self, parent):
        mixer.init()
        self.m1=mixer.Sound('Iron _Maiden.WAV')
        self._init_ctrls(parent)

    def OnButton1Button(self, event):
        self.m1.play()

    def OnButton2Button(self, event):
        self.Close()
