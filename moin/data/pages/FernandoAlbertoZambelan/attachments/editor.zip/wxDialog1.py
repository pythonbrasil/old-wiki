#Boa:Dialog:wxDialog1

from wxPython.wx import *
from wxPython.lib.buttons import *

def create(parent):
    return wxDialog1(parent)

[wxID_WXDIALOG1, wxID_WXDIALOG1BUTTON1, wxID_WXDIALOG1STATICBITMAP1, 
 wxID_WXDIALOG1STATICTEXT1, 
] = map(lambda _init_ctrls: wxNewId(), range(4))

class wxDialog1(wxDialog):
    def _init_utils(self):
        # generated method, don't edit
        pass

    def _init_ctrls(self, prnt):
        # generated method, don't edit
        wxDialog.__init__(self, id=wxID_WXDIALOG1, name='', parent=prnt,
              pos=wxPoint(244, 238), size=wxSize(504, 234),
              style=wxDEFAULT_DIALOG_STYLE, title='Sobre')
        self._init_utils()
        self.SetClientSize(wxSize(496, 207))

        self.staticText1 = wxStaticText(id=wxID_WXDIALOG1STATICTEXT1,
              label='\nAutor:Fernando Alberto Zambelan  \nIdade:13 Anos \n  \n Esse foi o meu Primeiro progama em python usando o boa constructor. ',
              name='staticText1', parent=self, pos=wxPoint(280, 8),
              size=wxSize(208, 144), style=0)

        self.button1 = wxButton(id=wxID_WXDIALOG1BUTTON1, label='OK',
              name='button1', parent=self, pos=wxPoint(288, 168),
              size=wxSize(80, 24), style=0)
        EVT_BUTTON(self.button1, wxID_WXDIALOG1BUTTON1, self.OnButton1Button)

        self.staticBitmap1 = wxStaticBitmap(bitmap=wxBitmap('C:/windows/desktop/progama\xe7\xe3o/editor de texto/icone.jpg',
              wxBITMAP_TYPE_JPEG), id=wxID_WXDIALOG1STATICBITMAP1,
              name='staticBitmap1', parent=self, pos=wxPoint(16, 8),
              size=wxSize(255, 191), style=0)

    def __init__(self, parent):
        self._init_ctrls(parent)

    def OnButton1Button(self, event):
        self.Destroy()
