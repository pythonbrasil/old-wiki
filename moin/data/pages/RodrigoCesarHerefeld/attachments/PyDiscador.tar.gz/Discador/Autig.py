#!/usr/bin/env python

from Interface import Interface
import os,sys

if __name__=="__main__":
    print(sys.argv[0])
    janela=Interface()
    janela.mainloop()