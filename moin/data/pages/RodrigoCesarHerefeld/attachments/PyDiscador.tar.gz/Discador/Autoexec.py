#
#-*- encoding: utf-8 -*-
#


import sys,os
import glob


class Autoexec:
    def __init__(self,nome):
        self.pos=glob.glob('pos/%s*'%nome)
        self.pre=glob.glob('pre/%s*'%nome)

    def __call__(self,tipo='pos'):
        if tipo=='pos':
            self.__Execpos()
        if tipo=='pre':
            self.__Execpre()

    def __Execpos(self):
        for nome in self.pos:
            if os.access(nome,os.X_OK):
                os.system(nome)

    def __Execpre(self):
        for nome in self.pre:
            if os.access(nome,os.X_OK):
                os.system(nome)
            
        
