#
#-*- encoding: iso-8859-1 -*-

class config:
    def __init__(self,**valores):
        self.valores=valores
    
    def __getitem__(self,indice):
        return(self.valores[indice])
    
    def __setitem__(self,indice,valor):
        self.valores[indice]=valor



class ConfigParser:
    def __init__(self,file='/etc/wvdial.conf'):
        arquivo=open(file,'r')
        self.indices=[]
        self.configs={}
        self.conteudo=arquivo.readlines()
        arquivo.close()
        self.parsed_names=False
        
    def parse_names(self):
        nomes=[]
        for linha in self.conteudo:
            if linha[0]=='[':
                nomes.append(linha)
                self.indices.append(self.conteudo.index(linha))
        ret=[]
        for campo in nomes:
            campo=campo.replace('Dialer','')
            campo=campo.replace('[','')
            campo=campo.replace(']','')
            campo=campo.replace(' ','')
            tam=len(campo)
            ret.append(campo[:tam-1])
        self.parsed_names=True
        self.nomes=ret
        return(ret)

    def parse_config(self):
        if not self.parsed_names:
            self.parse_names()
        ultimo=len(self.indices)
        ultima_linha=len(self.conteudo)
#        for c in range(ultimo):
#            nome=self.nomes[c]
#            self.configs[nome]=config()
#            if c != ultimo:
#                
#            
    
    
if __name__=="__main__":
    teste=ConfigParser()
    nomes=teste.parse_names()
    teste.parse_config()