#
#-- encoding: utf8 --
#
from Tkinter  import Tk
from ConfigParser import *
from rwidgets import MButton
from Pmw import SelectionDialog


class Configuracao:
    def __init__(self,path='/etc/wvdial.conf'):
        self.parser=ConfigParser(path)
    
    def Escolha(self):
        '''Escolhe o provedor de internet para discar'''
        ch=SelectionDialog(None,
            title='PyDial',
            buttons=('Ok','Cancelar'),
            defaultbutton='Ok',
            scrolledlist_labelpos='n',
            label_text = 'Escolha o provedor:',
            scrolledlist_items=self.parser.parse_names())
        ch.show()
        if ch.activate()=='Ok':
            try:
                return(ch.getvalue()[0])
            except:
                return('Nenhum')
        else:
            return('Nenhum')

    
if __name__=="__main__":
    e=Tk()
    cf=Configuracao()    
    print(cf.Escolha())