#
#-*-encoding: iso-8859-1  -*-
#


from Tkinter import Label
from pickle import load,dump
from Configuracao import config
from TesteConexao import TesteConexao
from Autoexec import Autoexec

import tkMessageBox
import os

class Discador(Label):
    def __init__(self,parent,nome='Nenhum'):
        Label.__init__(self,parent,background='#ffffff',relief='ridge')
        self.nome=nome
        self.tester=TesteConexao(self,'ppp0')
        self.conectado=self.tester.conectado
        if self.tester.conectado:
            self['text']='Conectado'
        else:
            self['text']='Discar: %s'%self.nome

    def setTester(self,tester):
        self.tester=tester
    
    def discar(self):
        if self.tester.testar_conexao():
            tkMessageBox.showwarning('PyDial','J� conectado!!')
        else:
            if self.nome=='Nenhum':
                tkMessageBox.showerror('PyDial','Escolha um provedor para discar!')
            else:
                ex=Autoexec(self.nome)
                ex('pre')
                os.system('wvdial %s &'%self.nome)
                self.__wait_for_conection()
    
    def SetNome(self,nome):
        self.nome=nome
        if not self.tester.conectado:
            self['text']='Discar: %s'%nome
        else:
            self['text']='Conectado'
    
    def desconectar(self):
        #if not self.tester.conectado:return
        if tkMessageBox.askyesno('PyDial','Desconectar?'):
            os.system("kill `ps ax|grep wvdial|grep -v  grep |awk '{print $1}'`")

    def __wait_for_conection(self,evt=None):
        if self.tester.conectado:
            if not self.conectado:
                ex=Autoexec(self.nome)
                ex('pos')
                self['text']='Conectado'
                self.conectado=True
        else:
            if self.conectado:
                self['text']='Discar %s'%self.nome
                self.conectado=False
        self.after(1000,self.__wait_for_conection)
