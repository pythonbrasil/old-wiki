#
#-- encoding: utf8 --
#


from Tkinter import Frame,Tk,Image
from rwidgets import *
from rwidgets.MDI import *
from menu import menu
#from ToolBar import ToolBar
from TesteConexao import TesteConexao
from Discador import Discador
from  Configuracao import Configuracao
import tkMessageBox

class Interface(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.wm_title('PyDiscador')
        self.m=menu(self)
        self['menu']=self.m
        self.discador=Discador(self)
        self.tb=Toolbar(self)
        self.im1=Image('photo',file='Imagens/conectar.gif')
        self.im2=Image('photo',file='Imagens/desconectar.gif')
        st=Stock()
        self.im3=st['exit']
        self.tester=TesteConexao(self.tb,'ppp0')
        self.tester.pack(side='left')
        self.tb.add(self.im1,self.discador.discar)
        self.tb.add(self.im2,self.discador.desconectar)
        self.tb.add(self.im3,self.sair,'right')
        self.tb.addSeparator('right')
        self.discador.setTester(self.tester)
        self.tb.pack(side='top',fill='x')
        self.wm_protocol('WM_DELETE_WINDOW',self.sair)
        self.wm_geometry('200x70+100+100')
        self.discador.pack(side='bottom',fill='both',expand='1')
        self.configuracao=Configuracao()
        self.discador.SetNome(self.configuracao.parser.parse_names()[0])
    
    def escolher_provedor(self):
        self.discador.SetNome(self.configuracao.Escolha())
    
    def sair(self,evt=None):
        if tkMessageBox.askyesno('PyDial','Sair?'):
            self.destroy()


if __name__=="__main__":
    i=Interface()
    i.mainloop()



