#
#-- encoding: iso8859  --
from Tkinter import Frame,Text,tkinter
from rwidgets.MDI import MDIChild
from ScrolledText import *
import os
import tkMessageBox
import sys
import tryConnect

class Itelefonica(MDIChild):
    def __init__(self,parent,app):
        MDIChild.__init__(self,parent,'Conectar � ITELEFONICA',20,20,300,300)
        self.app=app
        self.output=ScrolledText(self,background='#ffffff')
        self.output.pack(side='top',fill='both',expand='1')
        self.saida=None
        self.conectar=False
        
    def conecta(self):
        self.conectar=True
        try:
            print('Conectando-se � Itelefonica')
            (entrada , saida) = os.popen4('wvdial --config /Programas/auth_if/Autig/etc/Itelefonica')
            self.saida=saida
            tkinter.createfilehandler(saida,tkinter.READABLE,self.conectando)
            entrada.close()
            self.after(1000,self.verifica)
        except Exception,e:
            self.conectar=False
            print('Erro conectando \n%s\n '%str(e))

    def conectando(self,arquivo,lixo=None):
        if not arquivo.closed and self.conectar:
            data=arquivo.readline()
            self.output.insert('end',str(data))
        else:
            print('!')
            tkinter.deletefilehandler(arquivo)
    
    def desconecta(self):
        if self.saida!=None:
            print('Desconectando-se da Itelefonica')
            self.conectar=False
            os.system("kill  `ps ax|grep wvdial|grep -v  grep|awk '{print $1}'`")
            if not tryConnect.tryConnect('ppp0'):
                self.output.insert('end','\nDesconectando\n\n')
                self.app.Desconectado()
        else:
            tkMessageBox.showwarning('pyDial','N�o conectado\n')
    
    def verifica(self):
        if tryConnect.tryConnect('ppp0'):
            self.app.Conectado()
        else:
            self.after(1000,self.verifica)