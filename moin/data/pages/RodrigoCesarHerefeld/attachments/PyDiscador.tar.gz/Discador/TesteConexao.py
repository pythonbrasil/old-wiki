#
#-- encoding: utf8 --
from Tkinter import Button,Image
from os import popen4



class TesteConexao(Button):
    def __init__(self,parent,interface):
        self.interface=interface
        self.verde=Image('photo',file='Imagens/verde.gif')
        self.vermelho=Image('photo',file='Imagens/vermelho.gif')
        self.conectado=self.testar_conexao()
        if self.conectado:
            Button.__init__(self,parent,relief='flat',state='disabled',image=self.verde)
        else:
            Button.__init__(self,parent,relief='flat',state='disabled',image=self.vermelho)
        self.after(1000,self.__cont)


    def testar_conexao(self,evt=None):
        file=open('/proc/net/dev')
        conteudo=file.readlines()
        for linha in conteudo:
            if linha.find(self.interface)>=0:
                return(True)
        return(False)

    def __cont(self):
        if self.testar_conexao():
            self['image']=self.verde
            self.conectado=True
        else:
            self['image']=self.vermelho
            self.conectado=False
        self.after(1000,self.__cont)

    def IsConnected(self):
        return(self.__cont())


if __name__=="__main__":
    from Tkinter import Tk
    e=Tk()
    teste=TesteConexao(e,'ppp0')
    teste.pack()
    e.mainloop()
