#
#-- encoding: utf8 --
#
from Tkinter import Menu

class menu(Menu):
    def __init__(self,parent):
        Menu.__init__(self,parent)
        self.parent=parent
        self.add_cascade(0,menu=self.MainMenu(),label='Conexão')
        #self.add_cascade(0,menu=self.MenuConfigurar(),label='Configuração')

    def MainMenu(self):
        m=Menu(self)
        m.add_command(0,label='Escolher provedor',command=self.parent.escolher_provedor)
        m.add_separator(0)
        m.add_command(0,label='Sair',command=self.parent.sair)
        return(m)
    
    def MenuConfigurar(self):
        m=Menu(self)
        m.add_command(0,label='Configurar')
        return(m)



