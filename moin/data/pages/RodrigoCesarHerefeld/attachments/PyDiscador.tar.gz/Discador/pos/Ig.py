#!/usr/local/bin/python
#-*- coding:  utf-8  -*-
#----------------------------------------------------------------------------------
#Este script autentica o Ig depois da conexao
#Coloque o seu nome de usuario e senha abaixo
#pra fazer funcionar
#
import urllib
import sys
import re
import Tkinter 
import tkMessageBox

nome=''
senha=''

e=Tkinter.Tk()
e.wm_withdraw()
class auth:
    def __init__(self):
        self.endereco = "http://auth.ig.com.br/servlets/autentica"
        self.cnstr="action=login&url=http%3A%2F%2Fwww.debian.org&cpssg=&cpkey=&metodo=Gateway&username="+nome+"&password="+senha+"&submit=ok"

    def __call__(self):
        try:
            ret =urllib.urlopen(self.endereco,self.cnstr)
        except:
            tkMessageBox.showerror('Autig','Site n�o responde')
            sys.exit(1)
        data = ret.read();
        if(re.search("Carregando",data)):
            return(True)
        else:
            return(False)



if __name__=="__main__":
    at=auth()
    while not at():
        resp=tk_MessageBox.askyesno('Autig','Erro na autentica��o!\nTentar novamente?')
        if not resp:
            sys.exit(0)
        
    tkMessageBox.showinfo('Autig','Ig autenticado')


