#
#-*- coding utf-8 -*-
#
from Tkinter import *
from MDI import *
from MButton import *
from LEntry import *
from ScrolledListbox import *
from Stock import Stock
from Toolbar import *
import tkMessageBox

class Demo(Tk):
    def __init__(self):
        Tk.__init__(self)
        self.wm_title('RWidgets Demo')
        self.wm_protocol('WM_DELETE_WINDOW',self.sair)
        self.geometry('600x400+50+50')
        #Toolbar
        tb=Toolbar(self)
        st=Stock()
        tb.add(st['back'],None)
        tb.add(st['next'],None)
        tb.addSeparator()
        tb.add(st['trash'],None)
        tb.addSeparator()
        tb.add(st['new'],None)
        tb.add(st['floppy'],None)
        tb.addSeparator()
        tb.add(st['folder'],None)
        tb.addSeparator()
        tb.add(st['exit'],self.sair)
        tb.pack(side='top',fill='x')
        #
        #The Desktop
        desktop=MDIDesktop(self)
        desktop.pack(side='top',fill='both',expand='1')
        #
        #A empty MDI Child
        vazio=MDIChild(desktop,'An empty MDI Child',30,60,200,80)
        #
        ScrolledList_Demo(desktop)
        MButton_Demo(desktop,st)
        Entrys_Demo(desktop)
        #
        
    def sair(self):
        if tkMessageBox.askyesno('Demo','Close?'):
            self.quit()
        
class ScrolledList_Demo:
    def __init__(self,parent):
        base=MDIChild(parent,'Scrolled Listbox Demo',12,12,160,200)
        sc=ScrolledListbox(base)
        sc.pack(side='top',fill='both')
        sc.insert('end','This is the Scrolled Listbox Demo')
        sc.insert('end','Is a simple Listbox')
        sc.insert('end','With all the caracteristcs')
        sc.insert('end','I think is realy a listbox')
        sc.insert('end','Yes just a listbox')
        sc.insert('end','Well i think')
        sc.insert('end','It must be')
        sc.insert('end','Yes it is')
        sc.insert('end','So, you ask what is diferent')
        sc.insert('end','Why write another??')
        sc.insert('end','Well this one has automatic scroll')
        sc.insert('end','Just that!')

class MButton_Demo:
    def __init__(self,parent,stock):
        #Stock comes from the Main demo when was used in the toolbar
        base=MDIChild(parent,'Moving Buttons demo And Stock',30,30,340,130)
        lb=Label(base,text='This is a demo off buttons with relief sensitive to mouse\nAnd some built in images (called Stock)\n You see then in the Toolbar too')
        lb.pack(side='top',fill='both')
        bt=MButton(base,text='This is Text')
        bt2=MButton(base,image=stock['folder'])
        bt3=MButton(base,text='This is text too')
        bt.pack(side='left')
        bt2.pack(side='left')
        bt3.pack(side='left')

class Entrys_Demo:
    def __init__(self,parent):
        base=MDIChild(parent,'Special Entrys',60,60,260,200)
        lb=Label(base,text='This are masked entrys they use a mask\n like ##/##/## for dates like 01/01/2001\nThere are two classes \nLEntry with label and \nFEntry with just  mask')
        lb.pack(side='top',fill='x')
        et=LEntry(base,label='This mask is ##/##/####',mask='##/##/####')
        et.pack(side='top',fill='x')
        et2=LEntry(base,label='This is a telephone mask',mask='(##)####-####')
        et2.pack(side='top',fill='x')
        
if __name__=="__main__":
    demo=Demo()
    demo.mainloop()