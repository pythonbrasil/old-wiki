#
#--encoding:utf8 --
from Tkinter import Entry
from string import find


class FEntry(Entry):
    def __init__(self,parent,args):
        ''' FEntry(parent,**args)
            Creates one Entry that accepts a mask
            and formats the input as the user types
            args=>The same off a entry excepts that
            it does not uses vcmd and validate
            and have another parameter called mask
            mask=\'the mask\'
            'the mask' is sth like ##/##/#### for a date like 01/01/2001
            The parameter are
            # -> A Number
            a -> A ascii leter(by now it does not accepts non-ascii caracters)
            A -> Anything
            s or S -> a math signal (.+-*/=-)
        '''
        if args.has_key('vcmd'):
            del(args['vcmd'])
        if args.has_key('validate'):
            del(args['validate'])
        if args.has_key('mask'):
            self.__mask=args['mask']
            del(args['mask'])
        else:
            self.__mask=None
            
        Entry.__init__(self,parent,args)
        if self.__mask!=None:
            self.__format()
        else:
            self.__unformat()
        self.parent=parent
        tkcmd=parent.register(self.__validar)
        Entry.__setitem__(self,'vcmd',(tkcmd,"%S","%d","%i"))
        
    def __doc__(self):
        return("FEntry(parent,**args)\n\
            Creates one Entry that accepts a mask\n\
            and formats the input as the user types\n\
            args=>The same off a entry excepts that\n\
            it does not uses vcmd and validate\n\
            and have another parameter called mask\n\
            mask='the mask'\n\
            'the mask' is sth like ##/##/#### for a date like 01/01/2001\n\
            The parameter are\n\
            # -> A Number\n\
            a -> A ascii leter(by now it does not accepts non-ascii caracters)\n\
            A -> Anything\n\
            s or S -> a math signal (.+-*/=-)")

    def __setitem__(self,indice,valor):
        if indice!='vcmd' and indice!='validate':
            Entry.__setitem__(self,indice,valor)
        
    def __format(self):
        Entry.__setitem__(self,'validate','key')
        
    def __unformat(self):
        Entry.__setitem__(self,'validate','none')
      
    def mask(self,mascara=''):
        if mascara=='' or mascara==None:
            self.__mask=None
            self.__unformat()
        else:
            self.__mask=mascara
            self.__format()
    
    def __validar(self,tecla,inserir,indice):
        letras='ABCDEFGHIJKLMNOPQRSTUVXWYZabcdefghijklmnopqrstuvxwyz'
        numeros='1234567890'
        sinais='.+-*/=!,'
        texto=self.get()
        tmask=len(self.__mask)
        tamanho=len(texto)
        if not int(inserir):
            if int(indice)>=(tamanho-1):
                return(True)
            else:
                self.__unformat()
                self.delete('0','end')
                self.__format()
                return(False)
        if (len(texto)-1>tmask):
            return(False)
        if int(indice)>=len(self.__mask):
            return(False)
        MC=self.__mask[int(indice)]
        if(MC!='#' and MC!='A' and MC!='a' and MC!='s' and MC!='S'):
            if int(inserir):
                self.__unformat()
                if int(indice)<(len(self.__mask)-2):
                    if self.__validar(tecla,1,(int(indice)+1)):
                        self.insert(indice,MC)
                        self.insert(int(indice)+1,tecla)
                else:
                        self.insert(indice,MC)
                self.__format()
                return(False)
        if MC=='#' and (find(numeros,tecla)>=0):
            return(True)
        if MC=='A':
            return(True)
        if MC=='a' and (find(letras,tecla)>=0):
            return(True)
        if (MC=='s' or MC=='S') and (find(sinais,tecla)>=0):
            return(True)
        return(False)
        
    