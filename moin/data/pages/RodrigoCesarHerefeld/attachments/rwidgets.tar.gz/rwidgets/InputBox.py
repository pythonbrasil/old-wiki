#!/usr/bin/env python

from wxPython.wx import *

class InputBox(wxDialog):
    def __init__(self,parent=None,titulo='',mensagem=''):
        wxDialog.__init__(self,parent, -1, titulo)
        self.label_1 = wxStaticText(self, -1, mensagem)
        self.text_ctrl_1 = wxTextCtrl(self, -1, "")
        self.button_1 = wxButton(self, -1, "Ok")
        self.button_2 = wxButton(self, -1, "Cancelar")
        self.__do_layout()
        self.button_1.SetDefault()

    def __do_layout(self):
        grid_sizer_1 = wxFlexGridSizer(4, 1, 0, 0)
        grid_sizer_2 = wxFlexGridSizer(2, 5, 0, 0)
        grid_sizer_1.Add(self.label_1, 0, 0, 0)
        grid_sizer_1.Add(self.text_ctrl_1, 0, wxEXPAND, 0)
        grid_sizer_1.Add(20, 20, 0, 0, 0)
        grid_sizer_2.Add(20, 20, 0, 0, 0)
        grid_sizer_2.Add(self.button_1, 0, wxEXPAND, 0)
        grid_sizer_2.Add(20, 20, 0, 0, 0)
        grid_sizer_2.Add(self.button_2, 0, wxEXPAND, 0)
        grid_sizer_2.Add(20, 20, 0, 0, 0)
        grid_sizer_2.Add(20, 10, 0, 0, 0)
        grid_sizer_2.Add(20, 10, 0, 0, 0)
        grid_sizer_2.Add(20, 10, 0, 0, 0)
        grid_sizer_2.Add(20, 10, 0, 0, 0)
        grid_sizer_2.Add(20, 10, 0, 0, 0)
        grid_sizer_2.AddGrowableCol(1)
        grid_sizer_2.AddGrowableCol(3)
        grid_sizer_1.Add(grid_sizer_2, 1, wxEXPAND, 0)
        self.SetAutoLayout(1)
        self.SetSizer(grid_sizer_1)
        grid_sizer_1.Fit(self)
        grid_sizer_1.SetSizeHints(self)
        grid_sizer_1.AddGrowableCol(0)
        self.Layout()


class teste(wxApp):
	def OnInit(self):
		return(True)
		
if __name__=="__main__":
	janela=InputBox('Teste','Digite algo:')
	janela.ShowModal()
	app=teste()