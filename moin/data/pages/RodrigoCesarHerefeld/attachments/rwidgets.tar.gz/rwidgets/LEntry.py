#
#-- encoding: utf8 --
from Tkinter import LabelFrame
from FEntry import FEntry



class LEntry(LabelFrame):
    def __init__(self,parent,**args):
        entryargs={}
        if args.has_key('mask'):
            entryargs['mask']=args['mask']
            args.pop('mask')
        else:
            entryargs['mask']=None
        if args.has_key('textvariable'):
            entryargs['textvariable']=args['textvariable']
            args.pop('textvariable')
        if args.has_key('label'):
            args['text']=args['label']
            args.pop('label')
        if not args.has_key('relief'):
            args['relief']='flat'
        LabelFrame.__init__(self,parent,args)
        entryargs['background']='#ffffff'
        self.__entry=FEntry(self,entryargs)
        self.__entry.pack(side='top',fill='both')
        
        
    def __getitem__(self,indice):
        if indice=='mask' or indice=='textvariable':
            return(self.__entry[indice])
        else:
            if indice=='label':
                return(LabelFrame.__settitem__(self,'text',valor))
            else:
                return(LabelFrame.__setitem__(self,indice,valor))
                
    
    def __setitem__(self,indice,valor):
        if indice=='mask' or indice=='textvariable':
            self.__entry[indice]=valor
        else:
            if indice=='label':
                return(LabelFrame.__setitem__(self,'text',valor))
            else:
                return(LabelFrame.__setitem__(self,indice,valor))

    def insert(self,indice,valor):
        self.__entry.insert(indice,valor)
    
    def delete(self,indice1,indice2):
        self.__entry.delete(indice1,indice2)
    
    def get(self):
        return(self.__entry.get())
    
if __name__=="__main__":
    import Tkinter
    janela=Tkinter.Tk()
    teste=LEntry(janela,label='Teste')
    teste.pack()
    janela.mainloop()