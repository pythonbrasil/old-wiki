from Tkinter import Button
#--encoding utf8 --


class MButton(Button):
    def __init__(self,parent,**args):
        Button.__init__(self,parent,args)
        self.__relief('off')
        self.bind('<Enter>',self.on)
        self.bind('<Leave>',self.off)
        
    def __setitem__(self,item,value):
        if item!='relief':
            Button.__setitem__(self,item,value)
    
    def __relief(self,stat='Off'):
        if stat!='off':
            Button.__setitem__(self,'relief','raised')
        else:
            Button.__setitem__(self,'relief','flat')
            
    def on(self,evt):
        self.__relief('on')
        
    def off(self,evt):
        self.__relief('off')
