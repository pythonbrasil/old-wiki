from Tkinter import *
#-- encoding: utf8 --
#MDI Child for python Tkinter
#Developed by Rodrigo Cesar Herefeld
#Some codes that does the move and resize were adaptade from a MDI example
#for tcl from the site http://www.tcl.tk
#The button's images where copied from the gtk-2.0 AquaX theme by (eric@simweb.com)
#My thanks(i don't know the name of the guy if somebody knows please tell me)
#All the code is protected by the Library Gnu Public License and you must
#agree with this to use this code in your programs



#Classe dos botoes da barra de janelas do desktop
class Buttonapp(Frame):
    def __init__(self,parent,image,text):
        Frame.__init__(self,parent,relief='flat',border=1)
        self.__label1=Label(self,image=image)
        self.__label2=Label(self,text=text)
        self.__label1.pack(side='left')
        self.__label2.pack(side='left')
        
    def __setitem__(self,indice,valor):
        if indice=='image':
            self.__label1['image']=valor
            return
        if indice=='text':
            self.__label2['text']=valor
            return
        if indice=='command':
            self.__label1.bind('<1>','')
            self.__label2.bind('<1>','')
            self.__label1.bind('<1>',valor)
            self.__label2.bind('<1>',valor)
            return
        Frame.__setitem__(self,indice,valor)
        

    def __getitem__(self,indice):
        if indice=='image':
            return(self.__label1['image'])
        if indice=='text':
            return(self.__label2['text'])
        return(Frame.__getitem__(self,indice))

class MDIChild(Frame):
    def __init__(self,parent,titulo='MDI-Child',x=10,y=10,w=100,h=100):
        self.parent=parent
        self.nx=x
        self.ny=y
        self.x=x
        self.y=y
        self.qx=0
        self.qy=0
        self.width=w
        self.height=h
        self.state='normal'
        self.astate='normal'
        self.has_focus=True
        self.__title=titulo
        self.parent.add_child(self)
        self.Imagens()
        self.__top=PanedWindow(self.parent,relief='ridge') 
        Frame.__init__(self,self.__top,relief='ridge')
        self.bind('<1>',self.__up)
        self.__m(titulo)
        #----------------
        bot=Frame(self.__top,relief='raised',height=1,width=1,cursor='double_arrow')
        r=Frame(self.__top,relief=RIDGE,cursor='right_side')
        rup=Frame(r,relief='ridge',cursor='right_side')
        rb=Frame(r,relief='ridge',cursor='sizing')
        r.pack(side='right',fill='y')
        rup.pack(side='top',fill='y')
        rb.pack(side='bottom',expand='false')
        #
        bot.pack(side='bottom',fill='x')
        #
        self.pack(side='top',fill='both',expand='1')
        self.__top.place(x=x,y=y,width=w,height=h)
        #
        tkcmd=self.register(self.resize_start)
        r.bind('<1>',self.resize_start)
        bot.bind('<1>',self.resize_start)
        rb.bind('<1>',self.resize_start)
        #
        r.bind('<B1-Motion>',lambda event,lado='direito':self.resize_do(event,lado))
        bot.bind('<B1-Motion>',lambda event,lado='baixo':self.resize_do(event,lado))
        rb.bind('<B1-Motion>',lambda event,lado='ambos':self.resize_do(event,lado))
        self.bt_app=Buttonapp(self.parent.app_bar,image=self.ImgMenu,text=titulo)
        self.bt_app.pack(side='left')
        self.bt_app['command']=self.bt_app_clicked
        self.bt_app['relief']='sunken'
        
    
    def resize_start(self,event):
        self.qx=int(self.__top.winfo_pointerx())
        self.qy=int(self.__top.winfo_pointery())
        if not self.has_focus:
            self.Raise()
    
    def resize_do(self,event,lado):
        if self.state=='maximized':return
        dx=int(self.__top.winfo_pointerx())-self.qx
        dy=int(self.__top.winfo_pointery())-self.qy
        cw=int(self.__top.winfo_width())
        ch=int(self.__top.winfo_height())
        new_w=cw+dx
        new_h=ch+dy
        if new_w >=100 and new_h >= 100:
            if lado=='direito':
                self.__top.place(width=new_w)
                self.qx=self.__top.winfo_pointerx()
            if lado=='baixo':
                self.__top.place(height=new_h)
                self.qy=self.__top.winfo_pointery()
            if lado=='ambos':
                self.__top.place(width=new_w,height=new_w)
                self.qx=self.__top.winfo_pointerx()
                self.qy=self.__top.winfo_pointery()
            self.x=self.__top.winfo_x()
            self.y=self.__top.winfo_y()
            self.width=self.__top.winfo_width()
            self.height=self.__top.winfo_height()
    
    def __m(self,titulo):
        self.__title_bar=Frame(self.__top,relief='ridge',border=2,background='#39A9E2',cursor='hand2')
        self.__mbutton=Menubutton(self.__title_bar,
            image=self.ImgMenu,
            font='Arial,7,Bold',
            cursor='hand2',
            activebackground='#39A9E2',
            background='#39A9E2')
        self.__MenuBar_Menu()
        self.__mbutton.pack(side='left')
        self.__titulo=Label(self.__title_bar,text=titulo,background='#39A9E2',cursor='hand2')
        self.__title_bar.pack(side='top',fill='both')
        self.__titulo.pack(side='left',fill='x')
        #-----------------------
        #Minizar,maximizar e fechar
        self.__close=Button(self.__title_bar,
            font='Arial,7,Bold',
            cursor='hand2',
            background='#39A9E2',
            activebackground='#39A9E2',
            image=self.ImgFechar,
            relief='flat',
            highlightbackground='#39A9E2',
            borderwidth='0',
            command=self.fechar)
        self.__maximize=Button(self.__title_bar,
            image=self.ImgMaximizar,
            font='Arial,7,Bold',
            cursor='hand2',
            relief='flat',
            borderwidth='0',
            background='#39A9E2',
            activebackground='#39A9E2',
            highlightbackground='#39A9E2',
            command=self.maximize_restore)
        self.__minimize=Button(self.__title_bar,
            image=self.ImgMinimizar,
            relief='flat',
            borderwidth=0,
            font='Arial,7,Bold',
            cursor='hand2',
            background='#39A9E2',
            activebackground='#39A9E2',
            highlightbackground='#39A9E2',
            command=self.minimize)
        self.__close.pack(side='right')
        self.__maximize.pack(side='right')
        self.__minimize.pack(side='right')
        #
        self.__close.bind('<1>',self.start_move)
        self.__minimize.bind('<1>',self.start_move)
        self.__maximize.bind('<1>',self.start_move)
        self.__close.bind('<B1-Motion>',self.move_do)
        self.__minimize.bind('<B1-Motion>',self.move_do)
        self.__close.bind('<B1-Motion>',self.move_do)
        #
        self.__mbutton.bind('<1>',self.start_move)
        self.__mbutton.bind('<B1-Motion>',self.move_do)
        self.__title_bar.bind('<1>',self.start_move)
        self.__title_bar.bind('<B1-Motion>',self.move_do)
        self.__titulo.bind('<1>',self.start_move)
        self.__titulo.bind('<B1-Motion>',self.move_do)
        self.__titulo.lower()
    
    def __MenuBar_Menu(self):
        bt=Menu(self.__mbutton)
        bt.add_command(0,label='Maximizar',command=self.maximize)
        bt.add_command(0,label='Minimizar',command=self.minimize)
        bt.add_command(0,label='Restaurar',command=self.restore)
        bt.add_separator(0)
        bt.add_command(0,label='Fechar',command=self.fechar)
        self.__mbutton['menu']=bt
        
    def start_move(self,event):
        self.nx=int(self.parent.winfo_pointerx())
        self.ny=int(self.parent.winfo_pointery())
        self.Raise()
    
    def move_do(self,event):
        if self.state=='maximized':return
        x=int(self.parent.winfo_pointerx())
        y=int(self.parent.winfo_pointery())
        dx=x-self.nx
        dy=y-self.ny
        param=self.__top.place_info()
        px=int(param['x'])+dx
        py=int(param['y'])+dy
        if px<0 or py < 0 : return
        if px < (self.parent.winfo_width()-10) and py < (self.parent.winfo_height()-10):
            self.__top.place(x=px,y=py)
            self.nx=x
            self.ny=y
            self.x=px
            self.y=py

    
    def __up(self,evt=None):
        self.has_focus=True
        self.Raise()

    def Raise(self):
        self.__title_bar['background']='#39A9E2'
        self.__titulo['background']='#39A9E2'
        self.__mbutton['background']='#39A9E2'
        self.__mbutton['activebackground']='#39A9E2'
        self.__close['background']='#39A9E2'
        self.__close['activebackground']='#39A9E2'
        self.__close['highlightbackground']='#39A9E2'
        self.__maximize['background']='#39A9E2'
        self.__maximize['activebackground']='#39A9E2'
        self.__maximize['highlightbackground']='#39A9E2'
        self.__minimize['background']='#39A9E2'
        self.__minimize['activebackground']='#39A9E2'
        self.__minimize['highlightbackground']='#39A9E2'
        self.parent.child_get_focus(self)
        self.parent.tk.eval('raise %s'%self.__top)
        self.has_focus=True
        self.bt_app['relief']='sunken'
        
    def lower(self):
        self.has_focus=False
        self.bt_app['relief']='ridge'
        self.lost_focus()
        self.__top.lower()
    
    def maximize_restore(self,evt=None):
        if self.state=='iconic':return
        if self.state=='normal':
            self.maximize()
        else:
            self.restore()
            
    def set_title(self,tt):
        self.__title=tt
        self.__titulo['text']=tt
    
    def get_title(self):
        return(self.__title)
    
    def maximize(self):
        if self.state=='maximized': return
        self.width=self.__top.winfo_width()
        self.height=self.__top.winfo_height()
        self.__top.place(width=self.parent.winfo_width(),
            height=self.parent.winfo_height(),
            x=0,
            y=0)
        self.state='maximized'
        self.astate='maximized'
    
    def restore(self):
        if self.state=='normal':return
        self.__top.place(x=self.x,y=self.y,width=self.width,height=self.height)
        self.state='normal'
        self.astate='normal'
        
    def minimize(self):
        self.state='iconic'
        self.__top.place(width='0',height='0')
        
    def lost_focus(self):
        self.has_focus=False
        self.bt_app['relief']='flat'
        cor='#DFDADB'
        self.__title_bar['background']=cor
        self.__titulo['background']=cor
        self.__mbutton['background']=cor
        self.__mbutton['activebackground']=cor
        self.__close['background']=cor
        self.__close['activebackground']=cor
        self.__close['highlightbackground']=cor
        self.__maximize['background']=cor
        self.__maximize['activebackground']=cor
        self.__maximize['highlightbackground']=cor
        self.__minimize['background']=cor
        self.__minimize['activebackground']=cor
        self.__minimize['highlightbackground']=cor
        
    def destroy(self):
        self.bt_app.destroy()
        self.parent.delete_child(self)
        self.__title_bar.destroy()
        Frame.destroy(self)
        self.__top.destroy()
        
        
    
    def fechar(self,evt=None):
        if not self.has_focus:
            self.Raise()
        else:
            self.destroy()
            
    def bt_app_clicked(self,evt=None):
        if self.state=='iconic':
            if self.astate=='maximized':
                self.maximize()
            else:
                self.restore()
        else:
            self.Raise()
    
    
    def getIcon(self):
        return(self.__mbutton['image'])
        
    def setIcon(self,img):
        img.configure(width=16,height=16)
        selt.__mbuton['image']=img
    
    def Imagens(self):
        self.ImgFechar=Image('photo',data="R0lGODlhDgAOAKUAAKWlpVpaWiEhIRAQECkpKXNrc0pKQpmZmb29xtbW1szMzJSMjGNKSqWUjP/Wzu/n5+/n72ZmZmMhIYxSSsZzc96lnP+ZmdKSjDkpMYQpKa05OcZCQtZaUpxSUtZSQqU5MZQpIa8pJcc4K+dSQmgQDudjUudrY/eEc/+MhP+UjOd7a/+1nP97a/fGpXtaUmdOTnc1Lf///////////////////////////////////////////////////////////yH+FUNyZWF0ZWQgd2l0aCBUaGUgR0lNUAAh+QQBCgA/ACwAAAAADgAOAAAGn8CfEBAQDAgBgHD5KxgOiIRiYSgwC4yG4wF5OA6MiLAhmVAqFUvlQplgDj9GRqPZcDgdz0cDYvwkHyEiHncjHiIhGhk/JCEeHiUmkiUjIxokPxkbIyUnKCcpKiUcG5iaJp4pKygpJyUbID8TGiwnFiu3KSgsGh1CHxyqFi0rKyklH0suEya3LS0WKhpMPy8MHRQoFB0w1EIRDAbiAWJLQQA7")
        self.ImgMaximizar=Image('photo',data="R0lGODlhDgAOAKUAAKWlpVpaWikpKRAQECEhIWZmZkpKQoyMjL29vczMzMbGvZSMjDkpMXNrc0pSUtbWzufv7+/393ule5mZmRg5IVJzUq3OnDNmM0qEOWutQnO1OYTGSlKcMTp3JVqlGGu9KZTWSpzeWqXnY63vc2OlKb3/hMz/mWOMQtbvY5yUKVJjSv///////////////////////////////////////////////////////////////////////////////////yH5BAEKAD8ALAAAAAAOAA4AAAaLwJ8QEBAMCAGAcPkrGA6IhGLBaDAbjsMDEoE8JA7rb0KpSCxotKRCUToumIxcs8lwMBfDj9LxcD4fGhofHh4YFHseGR8bII0bgByIFIEgISIjIiEggYgXJJYiJaMjmx8XTR4hI6MmJiWaHhU/BxgbrK6vJRsYTBiiubAns0wdJyAoICkdKkzOSwVMQQA7")
        self.ImgMinimizar=Image('photo',data="R0lGODlhDgAOAKUAAKWlpWZmZjkpMRAQEFpaWq2trYxra4xSSqWUjMzMzNbW1sbGvcZzc//Wzu/n5//399KSjHtaUpmZmZQpIapuTeaYe/fGpf+1nIQpKbVKKd57QtaMMd6lQtp5IeeMMe+tKfe1Mf+ZM/+9Qv/GSq8pJf/eY4xSMffOOf//e5t4Nv//maqjo+e9Qq+SXdrWUohqY2tjSnNrMZyUKdbvY1JjSkpKQv///////////////////////////////////////yH+FUNyZWF0ZWQgd2l0aCBUaGUgR0lNUAAh+QQBCgA/ACwAAAAADgAOAAAGlMCfEBAQDASEgnD5MxwQCcUCcTAwnYyG4+FoQCLWn2RCqVjOlkuFgkH8DhnNhkOnbzaZw2/S6Xg+gCAfHn0TexsfISIjjCKCHiQ/GSEfIiWXlyAgIRk/JiEnI5colyMnISY/KRuiKCoosJcbET8rKSwlriq7JSwtSxEpLrqvLikvTDAxMi4zLjIxNExCATQ11wQBTEEAOw==")
        self.ImgMenu=Image('photo',data="R0lGODlhDwAKAKUAAI2UnLe3tsnJyc3NzczMzMrKyr6+vqKiotXV1efn5+rq6unp6ejo6N3d3bCwsHx8fLu7u9DQ0NfX19ra2tbW1tnZ2dHR0b+/v5CQkMfHx9TU1NPT08/Pz97e3uzs7PLy8vDw8O7u7u3t7eHh4dLS0vb29v39/fv7+/z8/Pr6+uTk5LS0tM7Ozrm5uYSEhIODg4WFhXl5ef///////////////////////////////////////////////////////yH+FUNyZWF0ZWQgd2l0aCBUaGUgR0lNUAAh+QQBCgA/ACwAAAAADwAKAAAGYcCfcEgsGo9DQEAwIDSdhIJheEAkFIsslqFoOH4PSAQhmVAklHPFcvlhMgONRKKpIxAbjkBI6Hg+ICAhgyEiIyRCDg0lJicoJ5AnKSpTQisFA5maAywtRA8uL6KjLzAxQkEAOw==")
        self.ImgMenu.configure(width=16,height=16)
        