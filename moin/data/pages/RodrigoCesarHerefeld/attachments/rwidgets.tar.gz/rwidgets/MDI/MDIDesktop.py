from Tkinter import Canvas,Menu,RIDGE,Frame,Menubutton,Image
#-- encoding: utf8 --

#MDI Desktop for Python Tkinter 
#Developed by Rodrigo Cesar Herefeld
#This code is distribuited in the therms of Gnu Public License Library

class Child:
    def __init__(self,child,indice):
        self.widget=child
        self.indice=indice


class MDIDesktop(Canvas):
    def __init__(self,parent,**args):
        self.parent=parent
        args['relief']=RIDGE
        args['background']='#7F7F7F'
        args['borderwidth']='3'
        self.container=Canvas(self.parent)
        Canvas.__init__(self,self.container,**args)
        self.focused=None
        self.winlist={}
        self.app_bar=Frame(self.container,relief='ridge',border='3')
        Canvas.pack(self,side='top',fill='both',expand='1')
        self.app_bar.pack(side='bottom',fill='x')
        
    
    def add_child(self,child):
        if self.focused!=None:
            self.focused.lost_focus()
        indice=len(self.winlist)
        self.winlist[child]=Child(child,indice)
        self.focused=child
        return(indice)
    
    def child_get_focus(self,child):
        if self.focused!=child:
            if self.focused!=None:
                self.focused.lost_focus()
            self.focused=child
            self.focused.Raise()
    
    def delete_child(self,child):
        if self.focused==child:
            self.focused=None
        self.winlist.pop(child)
        if len(self.winlist)>0:
            self.child_get_focus(self.winlist.keys()[0])
    
    
    def destroy(self):
        Canvas.destroy(self)
        self.container.destroy()
    
    def pack(self,**args):
        self.container.pack(args)
        
    def grid(self,**args):
        self.container.grid(args)
        
    def place(self,**args):
        self.container.place(args)
        
    
