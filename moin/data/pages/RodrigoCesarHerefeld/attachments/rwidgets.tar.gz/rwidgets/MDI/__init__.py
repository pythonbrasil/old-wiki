#
#--encoding: utf8 --

from MDIDesktop import MDIDesktop
from MDIChild import MDIChild
