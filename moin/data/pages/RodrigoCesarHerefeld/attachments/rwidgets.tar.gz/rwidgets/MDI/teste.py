from Tkinter import *
from MDIChild import *
from MDIDesktop import *

janela=Tk()
desktop=MDIDesktop(janela)

desktop.pack(side='top',fill='both',expand=1)

sub_janela=MDIChild(desktop)
sub_janela2=MDIChild(desktop,'Teste')

janela.geometry('350x350+200+100')
janela.mainloop()
