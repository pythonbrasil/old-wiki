from Tkinter import Listbox,Scrollbar,Frame



class ScrolledListbox(Listbox):
    def __init__(self,parent,**args):
        self.__container=Frame(parent)
        if not args.has_key('background'):
            args['background']='#ffffff'
        #
        fr1=Frame(self.__container)
        fr2=Frame(self.__container)
        fr3=Frame(self.__container)
        fr3.pack(side='bottom',fill='x')
        fr2.pack(side='right',fill='y')
        fr1.pack(side='left',fill='both',expand=1)
        #
        Listbox.__init__(self,fr1,args)
        self.__scv=Scrollbar(fr2,orient='vertical')
        self.__sch=Scrollbar(fr3,orient='horizontal')
        self.__sch.pack(side='top',fill='x')
        self.__scv.pack(side='right',fill='y')
        Listbox.pack(self,side='top',fill='both',expand='1')
        self['yscrollcommand']=self.__scv.set
        self['xscrollcommand']=self.__sch.set
        self.__scv['command']=self.yview
        self.__sch['command']=self.xview


    def pack(self,**args):
        self.__container.pack(args)

    def place(self,**args):
        self.__container.place(args)

    def grid(self,**args):
        self.__container.grid(args)

    def destroy(self):
        Listbox.destroy(self)
        self.__container.destroy()
