#
#-*- coding: utf-8 -*-
#
from Images1 import Images1
class Stock(dict):
    def __init__(self):
        dict.__init__(self)
        im=Images1()
        dict.update(self,im)