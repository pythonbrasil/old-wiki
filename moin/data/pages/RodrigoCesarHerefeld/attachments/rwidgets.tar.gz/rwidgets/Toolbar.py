#
#-- coding: utf-8 --
#

from Tkinter import Canvas,Image,Frame
from MButton import MButton

class ToolButton(MButton):
    def __init__(self,parent,Image,cmd,sd='left'):
        Image['width']=32
        Image['height']=32
        self.image=Image
        MButton.__init__(self,parent,image=Image,command=cmd)
        self.pack(side=sd)

class Separator(Frame):
    def __init__(self,parent,sd='left'):
        Frame.__init__(self,parent,width=2,relief='raised',borderwidth=32)
        self.pack(side=sd,fil='y')
        
class Toolbar(Frame):
    def __init__(self,parent):
        Frame.__init__(self,parent,relief='raised',height=38,border=3)
        
    def add(self,Image,command,side='left'):
        return(ToolButton(self,Image,command,side))
        
    def addSeparator(self,side='left'):
        sep=Separator(self,side)
        



if __name__=="__main__":
    from Tkinter import *
    from Stock import *
    jn=Tk()
    st=Stock()
    bar=Toolbar(jn)
    bar.pack(side='top',fill='x')
    for nome in st:
        bar.add(st[nome],None)
        bar.addSeparator()
    jn.mainloop()
