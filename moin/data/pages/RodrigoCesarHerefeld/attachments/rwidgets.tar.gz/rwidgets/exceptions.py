
from Exception import *




class VersionException(Exception):
    def __init__(self):
        Exception.__init__(self)
        
    def __str__(self):
        return('Erro de vers�o\nseu Tk � de uma vers�o antiga \nAs coisas podem n�o funcionar')