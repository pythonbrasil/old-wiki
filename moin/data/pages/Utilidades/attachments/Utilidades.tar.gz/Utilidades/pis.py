class Pis:
    """
    Class to work with PIS numbers
    """
    def __init__( self ):
        pass
    
    def validate( self, pis ):
        #TODO: Complete...
        """
        Method to validate Pis Numbers
        Based on: http://www.guj.com.br/posts/list/27363.java
        """
        if int(pis) == 0:
            return False
        
        if len(pis) != 11:
            return False
        
        