class Placa:
    """
    Class to work with car numbers ( placas )
    from brazil. Until now it justs validates the 
    number using a regex.
    """
    def __init__( self ):
        pass
    
    def validate( self, car_number ):
        """
        Method to validate car numbers
        Tests:
        
        >>> print Placa().validate("ABC1234")
        True
        >>> print Placa().validate("A2C1234")
        False
        """
        import re
        
        if re.match( "[A-Z][A-Z][A-Z][0-9][0-9][0-9][0-9]", car_number ) == None:
            return False
        else:
            return True
        

# tests
import doctest; doctest.testmod()