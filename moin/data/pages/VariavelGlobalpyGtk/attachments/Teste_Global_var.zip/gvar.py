#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-

import pygtk
pygtk.require('2.0')
import gtk.glade
import gobject
import gtk
import sys
import time
from win_principal import *

sys.path.append("")
v = winPrincipal(sys.argv)
gobject.idle_add(v.run)
gtk.main()