#!/usr/bin/env python
# -*- coding: iso-8859-1 -*-
import gtk
import gtk.glade as glade
from GladeConnect import GladeConnect
import sys
from time import *
import os
import config
from win_teste import *

    
class winPrincipal(GladeConnect):
    
    def __init__(self, args):
        GladeConnect.__init__(self,"win_vwlogin.glade")
        self.args = args
           
    def run(self):
        #self.winPrincipal.show()
        self.entUsuario.set_text('')
        self.entSenha.set_text('')
        self.entServidor.set_text('')
        self.entPorta.set_text('')
        login=dlgLogin()
        config.config = login
        self.entUsuario.set_text(login[0])
        self.entSenha.set_text(login[1])
        self.entServidor.set_text(login[2])
        self.entPorta.set_text(login[3])
   
    def on_bttTeste_clicked(self,source=None,event=None):
        
        winTeste()
        
    def gtk_main_quit(self,source=None,event=None):
        gtk.main_quit()
        
        

def dlgLogin():
        win_gl = glade.XML("win_login.glade")
        win = win_gl.get_widget('winLogin')
        usuario=win_gl.get_widget('entUsuario')
        senha=win_gl.get_widget('entSenha')
        servidor=win_gl.get_widget('entServidor')
        porta=win_gl.get_widget('entPorta')
        res = win.run()
        if res == gtk.RESPONSE_CANCEL:
            win.destroy()
            gtk.main_quit()
        else:
            win.destroy()
        login = [usuario.get_text(), senha.get_text(), servidor.get_text(), porta.get_text()]
        return login    


