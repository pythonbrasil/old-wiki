# -*- coding: iso-8859-1 -*-

import gtk
import gtk.glade as glade
from GladeConnect import GladeConnect
import config



class winTeste(GladeConnect):
    def __init__(self):
        GladeConnect.__init__(self,"win_vwlogin.glade")
        self.bttTeste.hide()
        login = config.config
        self.entUsuario.set_text(login[0])
        self.entSenha.set_text(login[1])
        self.entServidor.set_text(login[2])
        self.entPorta.set_text(login[3])
        
    def gtk_main_quit(self,source=None,event=None):
        gtk.main_quit()